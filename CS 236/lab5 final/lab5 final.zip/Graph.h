#pragma once
#ifndef GRAPH_H_
#define GRAPH_H_

#include "Node.h"
#include <vector>
#include <map>

using namespace std;

class Graph {
private:

public:
	map<int, Node> graph;


};
#endif