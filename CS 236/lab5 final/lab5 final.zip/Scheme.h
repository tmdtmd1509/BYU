#pragma once
#ifndef SCHEME_H_
#define SCHEME_H_

#include <vector>
#include "Parameter.h"
#include <iostream>

using namespace std;

class Scheme: public vector<string> {
private:
	vector<string> schemes;

public:

};

#endif