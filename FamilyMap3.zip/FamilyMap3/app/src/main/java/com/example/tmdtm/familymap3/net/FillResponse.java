package com.example.tmdtm.familymap3.net;

/**
 * Response of Fill
 * just a message, but include personNum and eventNum
 */
public class FillResponse {
    public String message;
    public int personNum;
    public int eventNum;
}
