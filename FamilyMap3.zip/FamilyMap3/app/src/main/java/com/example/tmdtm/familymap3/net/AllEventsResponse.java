package com.example.tmdtm.familymap3.net;

import com.example.tmdtm.familymap3.model.Event;

import java.util.List;

/**
 * response of all events
 */
public class AllEventsResponse {
    public List<Event> data;
    public String message;
}
