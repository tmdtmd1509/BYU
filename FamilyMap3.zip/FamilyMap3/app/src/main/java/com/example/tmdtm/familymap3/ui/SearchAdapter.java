package com.example.tmdtm.familymap3.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.tmdtm.familymap3.R;
import com.example.tmdtm.familymap3.model.Event;
import com.example.tmdtm.familymap3.model.Model;
import com.example.tmdtm.familymap3.model.Person;
import com.joanzapata.iconify.IconDrawable;
import com.joanzapata.iconify.fonts.FontAwesomeIcons;

import java.util.List;

public class SearchAdapter extends BaseAdapter {

    private Context context;
    private List<Object> list;

    private FontAwesomeIcons icon;
    private int color;

    public SearchAdapter(List<Object> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        Object item = getItem(position);
        if(view == null) {
            LayoutInflater childInfla = (LayoutInflater)this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = childInfla.inflate(R.layout.child_listview, null);
        }

        ImageView imageView = (ImageView)view.findViewById(R.id.child_item_icon);
        TextView textView = (TextView)view.findViewById(R.id.childText);

        if(item instanceof Event) {
            imageView.setImageDrawable(new IconDrawable(context, FontAwesomeIcons.fa_map_marker).colorRes(R.color.location).sizeDp(40));
            Event event = (Event) item;//TA qeustion
            Person person = Model.getModel().getPersonByPersonId(event.getPersonId());
            String text  = event.toString()+"\n"+person.toString();
            textView.setText(text);
        }
        else {
            Person person = (Person) item;

            if(person.getGender().equals("m")) {
                icon = FontAwesomeIcons.fa_male;
                color = R.color.male_icon;
            }
            else{
                icon = FontAwesomeIcons.fa_female;
                color = R.color.female_icon;
            }

            imageView.setImageDrawable(new IconDrawable(context, icon).colorRes(color).sizeDp(40));
            String text = person.toString();
            textView.setText(text);
        }
        return view;
    }
}
