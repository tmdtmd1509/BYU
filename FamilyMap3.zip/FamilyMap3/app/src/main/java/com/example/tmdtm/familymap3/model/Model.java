package com.example.tmdtm.familymap3.model;

import android.widget.Filter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Model {

    public Person user;
    public String authToken;

    public Person curPerson;
    public Event curEvent;

    public List<Person> personList;
    public List<Event> eventList;
    //personId people
    private HashMap<String, Person> people;
    //eventId, event
    private HashMap<String, Event> event;
    //personId, events list
    private HashMap<String, List<Event>> personEvents;//we nee to sort this
    private List<String> eventTypes;
    private Set<String> paternalAncestors;
    private Set<String> maternalAncestors;
    //personId 's child list
    private HashMap<String, List<Person>> personChildren;//we have only one child though

    private static Model model = new Model();
    private Model() {
        people = new HashMap<>();
        event = new HashMap<>();
        personEvents = new HashMap<>();
        personChildren = new HashMap<>();
        paternalAncestors = new HashSet<>();
        maternalAncestors = new HashSet<>();
    }

    public static Model getModel() {
        if(model == null) {
            model = new Model();
        }
        return model;
    }

    public void logIn() {
        if(user == null) {
            user = new Person();
        }
    }

    public void logout() {
        user = null;
        people = new HashMap<>();
        event = new HashMap<>();
        personEvents = new HashMap<>();
        personChildren = new HashMap<>();
        paternalAncestors = new HashSet<>();
        maternalAncestors = new HashSet<>();

        Fillter.getFillter().reset();
        Settings.getSettings().reset();
    }

    public boolean hasUser() {
        if(user == null) {
            return false;
        }
        return true;
    }

    public void makeMaps() {
        for(int i = 0; i < personList.size(); i++) {
            people.put(personList.get(i).getPersonId(), personList.get(i));
        }
        for(int i = 0; i < eventList.size(); i++) {
            event.put(eventList.get(i).getEventId(), eventList.get(i));
            personEvents.put(eventList.get(i).getPersonId(), eventsByPerson(eventList.get(i).getPersonId()));//need to check duplicate
        }
        addPersonChild();
        makeEventTypes();
        sideDevider();
    }

    private List<Event> eventsByPerson(String personId) {
        List<Event> listOfEvent = new ArrayList<>();
        for(Event evt : eventList) {
            if(personId.equals(evt.getPersonId())) {
                listOfEvent.add(evt);
            }
        }
        return listOfEvent;
    }

    public HashMap<String, Event> getEvent() {
        return event;
    }

    public HashMap<String, List<Event>> getPersonEvents() {
        return personEvents;
    }

    public HashMap<String, Person> getPeople() {
        return people;
    }

    public Person getPersonByPersonId(String personId) {
        return people.get(personId);
    }


    private void addPersonChild() {
        for(Person child : personList) {
            for(Person parent : personList) {
                if(child.getFather() != null && child.getMother() != null) {
                    if (child.getFather().equals(parent.getPersonId()) || child.getMother().equals(parent.getPersonId())) {
                        List<Person> children = new ArrayList<>();
                        children.add(child);
                        personChildren.put(parent.getPersonId(), children);
                    }
                }
            }
        }
    }
    public HashMap<String, List<Person>> getPersonChildren() {
        return personChildren;
    }

    private void makeEventTypes() {
        eventTypes = new ArrayList<>();
        eventTypes.add("Birth");
        eventTypes.add("Baptism");
        eventTypes.add("Marriage");
        eventTypes.add("Death");
    }

    public List<Event> getSortedEvents(List<Event> events) {
        List<Event> orderedList = new ArrayList<>();
        for(Event event : events) {
            if(event.getEventType().toLowerCase().contains("birth") &&
                    Fillter.getFillter().isBirth()) {
                orderedList.add(event);
            }
        }
        for(Event event : events) {
            if(event.getEventType().toLowerCase().contains("baptism") &&
                    Fillter.getFillter().isBaptism()) {
                orderedList.add(event);
            }
        }
        for(Event event : events) {
            if(event.getEventType().toLowerCase().contains("marriage") &&
                    Fillter.getFillter().isMarriage()) {
                orderedList.add(event);
            }
        }
        for(Event event : events) {
            if(!(event.getEventType().toLowerCase().contains("birth"))&&
                    !(event.getEventType().toLowerCase().contains("baptism"))&&
                            !(event.getEventType().toLowerCase().contains("marriage")) &&
                            !(event.getEventType().toLowerCase().contains("death"))) {
                orderedList.add(event);
            }
        }
        for(Event event : events) {
            if(event.getEventType().toLowerCase().contains("death") &&
                    Fillter.getFillter().isDeath()) {
                orderedList.add(event);
            }
        }
        return orderedList;
    }

    public void sideDevider() {
        if(user.getFather() != null && user.getMother() != null) {
            Person father = getPersonByPersonId(user.getFather());
            Person mother = getPersonByPersonId(user.getMother());

            paternalAncestors.add(user.getFather());
            maternalAncestors.add(user.getMother());

            fatherSideRecurse(father);
            motherSideRecurse(mother);
        }
    }

    private void fatherSideRecurse(Person person) {
        if(person.getFather() != null) {
            Person father = Model.getModel().getPersonByPersonId(person.getFather());
            paternalAncestors.add(father.getPersonId());
            fatherSideRecurse(father);
        }
        if(person.getMother() != null) {
            Person mother = Model.getModel().getPersonByPersonId(person.getMother());
            paternalAncestors.add(mother.getPersonId());
            fatherSideRecurse(mother);
        }
    }

    private void motherSideRecurse(Person person) {
        if(person.getFather() != null) {
            Person father = Model.getModel().getPersonByPersonId(person.getFather());
            maternalAncestors.add(father.getPersonId());
            motherSideRecurse(father);
        }
        if(person.getMother() != null) {
            Person mother = Model.getModel().getPersonByPersonId(person.getMother());
            maternalAncestors.add(mother.getPersonId());
            motherSideRecurse(mother);
        }
    }

    public Set<String> getPaternalAncestors() {
        return paternalAncestors;
    }
    public Set<String> getMaternalAncestors() {
        return maternalAncestors;
    }

}
