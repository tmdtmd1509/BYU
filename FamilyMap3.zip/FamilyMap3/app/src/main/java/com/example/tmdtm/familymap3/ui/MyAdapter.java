package com.example.tmdtm.familymap3.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.tmdtm.familymap3.R;
import com.example.tmdtm.familymap3.model.Model;
import com.example.tmdtm.familymap3.model.Person;
import com.joanzapata.iconify.IconDrawable;
import com.joanzapata.iconify.fonts.FontAwesomeIcons;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MyAdapter extends BaseExpandableListAdapter {
    private Context context;
    private List<String> parentList;
    private List<String> childList;
    private HashMap<String, List<String>> childHashMap;
    private Person curPerson;

    private FontAwesomeIcons icon;
    private int color;

    public MyAdapter(Context context, List<String> parentList, HashMap<String, List<String>> childHashMap, Person curPerson) {
        this.context = context;
        this.parentList = parentList;
        this.childHashMap = childHashMap;
        this.curPerson = curPerson;
    }

    @Override
    public int getGroupCount() {
        return parentList.size();
    }

    @Override
    public int getChildrenCount(int i) {
        return this.childHashMap.get(this.parentList.get(i)).size();
    }

    @Override
    public String getGroup(int position) {
        return parentList.get(position);
    }

    @Override
    public String getChild(int i, int i1) {
        return this.childHashMap.get(this.parentList.get(i)).get(i1);
    }

    @Override
    public long getGroupId(int position) {
        return position;
    }

    @Override
    public long getChildId(int i, int i1) {
        return i1;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int position, boolean isExpanded, View view, ViewGroup parent) {
        if(view == null) {
            LayoutInflater groupInfla = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = groupInfla.inflate(R.layout.parent_listview, parent, false);
        }

        TextView parentText = (TextView)view.findViewById(R.id.parentText);
        parentText.setText(getGroup(position));
        return view;
    }

    @Override
    public View getChildView(int i, int i1, boolean b, View view, ViewGroup viewGroup) {
        if(view == null) {
            LayoutInflater childInfla = (LayoutInflater)this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = childInfla.inflate(R.layout.child_listview, null);
        }
        ImageView imageView = (ImageView)view.findViewById(R.id.child_item_icon);
        TextView children = (TextView)view.findViewById(R.id.childText);

        //event is selected
        if(i == 0) {
            imageView.setImageDrawable(new IconDrawable(context, FontAwesomeIcons.fa_map_marker).colorRes(R.color.location).sizeDp(40));
            String text = getChild(i, i1)+"\n"+curPerson.toString();//TA qeustion
            children.setText(text);
        }
        else {
            String relationship = distinguishPerson(getChild(i, i1));
            imageView.setImageDrawable(new IconDrawable(context, icon).colorRes(color).sizeDp(40));
            String text = Model.getModel().getPersonByPersonId(getChild(i, i1)).toString() + "\n" + relationship;//TA question
            children.setText(text);
        }
        return view;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }

    private String distinguishPerson(String personId) {
        if(curPerson.getFather() != null && curPerson.getFather().equals(personId)) {
            icon = FontAwesomeIcons.fa_male;
            color = R.color.male_icon;
            return "Father";
        }
        else if(curPerson.getMother() != null && curPerson.getMother().equals(personId)) {
            icon = FontAwesomeIcons.fa_female;
            color = R.color.female_icon;
            return "Mother";
        }
        else if(curPerson.getSpouse() != null &&curPerson.getSpouse().equals(personId)) {
            if(Model.getModel().getPersonByPersonId(personId).getGender().equals("m")) {
                icon = FontAwesomeIcons.fa_male;
                color = R.color.male_icon;
            }
            else {
                icon = FontAwesomeIcons.fa_female;
                color = R.color.female_icon;
            }
            return "Spouse";
        }
        else if(Model.getModel().getPersonChildren().get(curPerson.getPersonId()).size() != 0){
            if(Model.getModel().getPersonByPersonId(personId).getGender().equals("m")) {
                icon = FontAwesomeIcons.fa_male;
                color = R.color.male_icon;
            }
            else {
                icon = FontAwesomeIcons.fa_female;
                color = R.color.female_icon;
            }
            return "Child";
        }
        else {
            return null;
        }
    }
}
