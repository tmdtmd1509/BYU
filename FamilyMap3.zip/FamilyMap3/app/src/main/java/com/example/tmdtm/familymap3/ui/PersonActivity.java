package com.example.tmdtm.familymap3.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.example.tmdtm.familymap3.MainActivity;
import com.example.tmdtm.familymap3.R;
import com.example.tmdtm.familymap3.model.Event;
import com.example.tmdtm.familymap3.model.Model;
import com.example.tmdtm.familymap3.model.Person;
import com.joanzapata.iconify.IconDrawable;
import com.joanzapata.iconify.fonts.FontAwesomeIcons;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PersonActivity extends AppCompatActivity{
    private Person curPerson;
    private TextView firstname;
    private TextView FIRST_NAME;
    private TextView lastname;
    private TextView LAST_NAME;
    private TextView gender;
    private TextView GENDER;
    private ExpandableListView elv;

    private List<String> parentList = new ArrayList<>();
    private List<String> eventsList = new ArrayList<>();
    private List<String> personList = new ArrayList<>();
    private HashMap<String, List<String>> childHashMap = new HashMap<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("FamilyMap: Person Details");

        //Bundle bundle = getIntent().getExtras();
        String personId = getIntent().getStringExtra("personId");
        curPerson = Model.getModel().getPersonByPersonId(personId);


        firstname = (TextView) findViewById(R.id.firstname);
        firstname.setText(curPerson.getFirstName());
        FIRST_NAME = (TextView) findViewById(R.id.firstnameView);
        lastname = (TextView) findViewById(R.id.lastname);
        lastname.setText(curPerson.getLastName());
        LAST_NAME = (TextView) findViewById(R.id.lastnameView);
        gender = (TextView) findViewById(R.id.gender);
        if(curPerson.getGender().equals("f")) {
            gender.setText("Female");
        }
        else if(curPerson.getGender().equals("m")) {
            gender.setText("Male");
        }
        GENDER = (TextView) findViewById(R.id.genderView);

        makeList();

        elv = (ExpandableListView) findViewById(R.id.person_information);
        final MyAdapter myAdapter = new MyAdapter(this, parentList, childHashMap, curPerson);
        elv.setAdapter(myAdapter);

        elv.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView expandableListView, View view, int groupPosition, int childPosition, long l) {
                if(groupPosition == 0) {
                    Intent intent = new Intent(PersonActivity.this, EventActivity.class);
                    intent.putExtra("eventId", Model.getModel().getPersonEvents().get(curPerson.getPersonId()).get(childPosition).getEventId());//works only when eventlist is sorted
                    startActivity(intent);
                }
                else {
                    String newPersonId = (String)expandableListView.getItemAtPosition(childPosition+2);//TA question
                    Intent intent = new Intent(getApplicationContext(), PersonActivity.class);
                    intent.putExtra("personId", newPersonId);
                    startActivity(intent);
                }
                return true;
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu_top, menu);
//
//        menu.findItem(R.id.menu_top).setIcon(new IconDrawable(this, FontAwesomeIcons.fa_angle_double_up)
//        .colorRes(R.color.menu));

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.home://need to fix
                finish();
                return true;
//            case R.id.menu_top:
//                Intent intent = new Intent(this, MainActivity.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                startActivity(intent);
//                finish();
//                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void makeList() {
        parentList.add("LIFE EVENTS");
        parentList.add("FAMILY");

        List<Event> listOfEvents = Model.getModel().getSortedEvents(Model.getModel().getPersonEvents().get(curPerson.getPersonId()));
        for(Event event : listOfEvents) {
            eventsList.add(event.toString());
        }

        if(curPerson.getSpouse() != null) {
            personList.add(curPerson.getSpouse());
        }
        if(curPerson.getFather() != null) {
            personList.add(curPerson.getFather());
        }
        if(curPerson.getMother() != null) {
            personList.add(curPerson.getMother());
        }
        if(Model.getModel().getPersonChildren().get(curPerson.getPersonId()) != null) {
            personList.add(Model.getModel().getPersonChildren().get(curPerson.getPersonId()).get(0).getPersonId());
        }
        childHashMap.put(parentList.get(0), eventsList);
        childHashMap.put(parentList.get(1), personList);
    }
}
