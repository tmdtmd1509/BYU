package com.example.tmdtm.familymap3.net;

/**
 * response of login
 */
public class LoginResponse {
    public String authToken;
    public String userName;
    public String personId;
    public String message;
}
