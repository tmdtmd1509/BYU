package com.example.tmdtm.familymap3.ui;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tmdtm.familymap3.MainActivity;
import com.example.tmdtm.familymap3.R;
import com.example.tmdtm.familymap3.model.Person;
import com.example.tmdtm.familymap3.model.User;
import com.example.tmdtm.familymap3.net.RegisterRequest;
import com.example.tmdtm.familymap3.net.AllEventsResponse;
import com.example.tmdtm.familymap3.net.EventResponse;
import com.example.tmdtm.familymap3.net.LoginResponse;
import com.example.tmdtm.familymap3.net.PeopleResponse;
import com.example.tmdtm.familymap3.net.PersonResponse;
import com.example.tmdtm.familymap3.model.Model;
import com.example.tmdtm.familymap3.net.ServerProxy;
import com.google.gson.Gson;

public class LoginFragment extends Fragment {

    private TextView serverHostView;
    private TextView serverPortView;
    private TextView usernameView;
    private TextView passwordView;
    private TextView firstnameView;
    private TextView lastnameView;
    private TextView emailView;

    private EditText serverHost;
    private EditText serverPort;
    private EditText username;
    private EditText password;
    private EditText firstname;
    private EditText lastname;
    private EditText email;
    private RadioGroup gender;
    //    private RadioButton male;
//    private RadioButton female;
    private Button signin;
    private Button register;

    String host;
    String port;
    String uName;
    String pWord;
    String fName;
    String lName;
    String eMail;
    String sex;

    public LoginFragment() {

    }

    private static LoginFragment loginFragment = new LoginFragment();
    public static LoginFragment getLoginFragment() {
        if(loginFragment == null) {
            return new LoginFragment();
        }
        return loginFragment;
    }

    public static LoginFragment newInstance() {
        return new LoginFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        //text view
        serverHostView = (TextView) view.findViewById(R.id.server_host_view);
        serverPortView = (TextView) view.findViewById(R.id.server_port_view);
        usernameView = (TextView) view.findViewById(R.id.user_name_view);
        passwordView = (TextView) view.findViewById(R.id.pass_word_view);
        firstnameView = (TextView) view.findViewById(R.id.first_name_view);
        lastnameView = (TextView) view.findViewById(R.id.last_name_view);
        emailView = (TextView) view.findViewById(R.id.e_mail_view);

        //sign in button
        signin = (Button) view.findViewById(R.id.sign_in);
        signin.setEnabled(false);

        //register button
        register = (Button) view.findViewById(R.id.register);
        register.setEnabled(false);

        //edit_text (server host)
        serverHost = (EditText) view.findViewById(R.id.server_host);
        serverHost.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence sequence, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence sequence, int start, int before, int count) {
                host = sequence.toString();
                checkLoginEnable(host, port, uName, pWord);
                checkRegisterEnable(host, port, uName, pWord, fName, lName, eMail, sex);
            }

            @Override
            public void afterTextChanged(Editable editable) { }
        });

        //edit_text (server port)
        serverPort = (EditText) view.findViewById(R.id.server_port);
        serverPort.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                port = charSequence.toString();
                checkLoginEnable(host, port, uName, pWord);
                checkRegisterEnable(host, port, uName, pWord, fName, lName, eMail, sex);
            }

            @Override
            public void afterTextChanged(Editable editable) { }
        });

        //....etc
        username = (EditText) view.findViewById(R.id.user_name);
        username.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                uName = charSequence.toString();
                checkLoginEnable(host, port, uName, pWord);
                checkRegisterEnable(host, port, uName, pWord, fName, lName, eMail, sex);
            }

            @Override
            public void afterTextChanged(Editable editable) { }
        });
        password = (EditText) view.findViewById(R.id.pass_word);
        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                pWord = charSequence.toString();
                checkLoginEnable(host, port, uName, pWord);
                checkRegisterEnable(host, port, uName, pWord, fName, lName, eMail, sex);
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        firstname = (EditText) view.findViewById(R.id.first_name);
        firstname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                fName = charSequence.toString();
                checkRegisterEnable(host, port, uName, pWord, fName, lName, eMail, sex);
            }

            @Override
            public void afterTextChanged(Editable editable) { }
        });

        lastname = (EditText) view.findViewById(R.id.last_name);
        lastname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                lName = charSequence.toString();
                checkRegisterEnable(host, port, uName, pWord, fName, lName, eMail, sex);
            }

            @Override
            public void afterTextChanged(Editable editable) { }
        });

        email = (EditText) view.findViewById(R.id.e_mail);
        email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                eMail = charSequence.toString();
                checkRegisterEnable(host, port, uName, pWord, fName, lName, eMail, sex);
            }

            @Override
            public void afterTextChanged(Editable editable) { }
        });

        //radio
        gender = (RadioGroup) view.findViewById(R.id.radio_button);

        gender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i == R.id.maleButton) {
                    sex = "m";
                    checkRegisterEnable(host, port, uName, pWord, fName, lName, eMail, sex);
                }
                else {
                    sex = "f";
                    checkRegisterEnable(host, port, uName, pWord, fName, lName, eMail, sex);
                }
            }
        });

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signInButtonClicked();
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerButtonClicked();
            }
        });

        return view;
    }

    private void checkLoginEnable(String host, String port, String username, String password) {
        if(host != null && port != null && username != null && password != null
                && !host.isEmpty() && !port.isEmpty() && !username.isEmpty() && !password.isEmpty()) {
            signin.setEnabled(true);
        }
        else {
            signin.setEnabled(false);
        }
    }

    private void checkRegisterEnable(String host, String port, String username, String password, String firstname, String lastname, String email, String gender) {
        if(host != null && port != null && username != null && password != null && firstname != null && lastname != null && email != null && gender != null
                && !host.isEmpty() && !port.isEmpty() && !username.isEmpty() && !password.isEmpty() && !firstname.isEmpty()
                && !lastname.isEmpty() && !email.isEmpty() && !gender.isEmpty()) {
            register.setEnabled(true);
        }
        else {
            register.setEnabled(false);
        }
    }

    private void signInButtonClicked() {
        try {
            LoginTask loginTask = new LoginTask();

            loginTask.execute();
        }
        catch (Exception e) {
            Log.e("LoginFragment", e.getMessage(), e);
        }
    }

    private void registerButtonClicked() {
        try {
            RegisterTask registerTask = new RegisterTask();

            registerTask.execute();

        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class LoginTask extends AsyncTask<Void, Integer, Boolean> {
        @Override
        protected Boolean doInBackground(Void... voids) {
            String json = ServerProxy.login(host, port, uName, pWord);
            if(json == null) {
                return false;
            }
            Gson gson = new Gson();
            LoginResponse loginResponse = gson.fromJson(json, LoginResponse.class);
            Model.getModel().logIn();
            Model.getModel().authToken = loginResponse.authToken;
            Model.getModel().user.setPersonId(loginResponse.personId);
            return true;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                PeopleTask peopleTask = new PeopleTask();
                peopleTask.execute(Model.getModel().authToken, host, port);
            } else {
                Toast.makeText(getActivity(), "login failed1", Toast.LENGTH_LONG).show();
            }
        }
    }

    public class PeopleTask extends AsyncTask<String, Integer, Boolean> {
        @Override
        protected Boolean doInBackground(String... strings) {
            //get people data
            String json1 = ServerProxy.people(strings[1], strings[2], strings[0]);
            if(json1 == null) {
                return false;
            }
            Gson gson = new Gson();
            PeopleResponse peopleResponse = gson.fromJson(json1, PeopleResponse.class);
            Model.getModel().personList = peopleResponse.data;

            //get event data
            String json2 = ServerProxy.event(strings[1], strings[2], strings[0]);
            if(json2 == null) {
                return false;
            }
            AllEventsResponse allEventsResponse = gson.fromJson(json2, AllEventsResponse.class);
            Model.getModel().eventList = allEventsResponse.data;

            //get user information
            String json3 = ServerProxy.person(strings[1], strings[2], strings[0], Model.getModel().user.getPersonId());
            if(json3 == null) {
                return false;
            }
            PersonResponse personResponse = gson.fromJson(json3, PersonResponse.class);
            //set root person
            Model.getModel().user.setPersonId(personResponse.personId);
            Model.getModel().user.setDescendant(personResponse.descendant);
            Model.getModel().user.setFather(personResponse.father);
            Model.getModel().user.setMother(personResponse.mother);
            Model.getModel().user.setFirstName(personResponse.firstName);
            Model.getModel().user.setLastName(personResponse.lastName);
            Model.getModel().user.setGender(personResponse.gender);
            Model.getModel().user.setSpouse(personResponse.spouse);

            return true;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                Model.getModel().makeMaps();
                //MainActivity activity = (MainActivity)getActivity();
                MainActivity mainActivity = ((MainActivity) getActivity());
                if(mainActivity != null) {
                    mainActivity.getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new MapFragment())
                            .addToBackStack(null).commit();
                }


            } else {
                Toast.makeText(getActivity(), "login failed2", Toast.LENGTH_LONG).show();
                //Toast.makeText(getActivity(), "Could not find the result", Toast.LENGTH_LONG).show();
            }
        }
    }

    public class RegisterTask extends AsyncTask<Void, Integer, Boolean> {
        @Override
        protected Boolean doInBackground(Void... voids) {
            User registerRequest = new User();
            registerRequest.setUsername(uName);
            registerRequest.setPassword(pWord);
            registerRequest.setFirstName(fName);
            registerRequest.setLastName(lName);
            registerRequest.setEmail(eMail);
            registerRequest.setGender(sex);

            String json = ServerProxy.register(host, port, registerRequest);
            if(json == null) {
                return false;
            }
            Gson gson = new Gson();
            LoginResponse loginResponse = gson.fromJson(json, LoginResponse.class);
            if(loginResponse.personId == null) {
                //Toast.makeText(getActivity(), loginResponse.message, Toast.LENGTH_LONG);
                return false;
            }
            Model.getModel().logIn();
            Model.getModel().authToken = loginResponse.authToken;
            Model.getModel().user.setPersonId(loginResponse.personId);
            return true;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                //Toast.makeText(getActivity(), "register success", Toast.LENGTH_LONG).show();
                LoginTask loginTask = new LoginTask();
                loginTask.execute();
            } else {
                Toast.makeText(getActivity(), "register failed", Toast.LENGTH_LONG).show();
            }
        }
    }
}
