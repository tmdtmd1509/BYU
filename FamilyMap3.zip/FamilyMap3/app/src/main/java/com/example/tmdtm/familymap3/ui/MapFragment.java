package com.example.tmdtm.familymap3.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tmdtm.familymap3.R;

import com.example.tmdtm.familymap3.model.Event;
import com.example.tmdtm.familymap3.model.Fillter;
import com.example.tmdtm.familymap3.model.Model;
import com.example.tmdtm.familymap3.model.Person;
import com.example.tmdtm.familymap3.model.Settings;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.*;
import com.joanzapata.iconify.Iconify;
import com.joanzapata.iconify.fonts.FontAwesomeIcons;
import com.joanzapata.iconify.fonts.FontAwesomeModule;
import com.joanzapata.iconify.IconDrawable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class MapFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener{
    private static final String ARG_EVENTID = "eventId";

    private GoogleMap mMap;
    private SupportMapFragment supportMapFragment;
    private Person curPerson = null;
    private Event curEvent = null;
    private Marker curMarker = null;

    private ImageView genderIcon;
    private TextView personName;
    private TextView eventInfo;
    private RelativeLayout information;

    private Set<Event> filtered;
    private Set<Marker> markers;
    private Set<Polyline> lines;



    private static MapFragment mapFragment = new MapFragment();
    public static MapFragment getMapFragment() {
        if(mapFragment == null) {
            return new MapFragment();
        }
        return mapFragment;
    }

    public static MapFragment getMapInstance(String eventId){
        MapFragment fragment = new MapFragment();
        Bundle args = new Bundle();
        args.putString(ARG_EVENTID, eventId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);//?? maybe not
        setHasOptionsMenu(!haveEventIdArgument());

    }

    private boolean haveEventIdArgument() {
        if(getArguments() != null && getArguments().containsKey(ARG_EVENTID)) {
            curEvent = Model.getModel().getEvent().get(getArguments().getString(ARG_EVENTID));
            return true;
        }
        else
            return false;
    }

    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_map, container, false);

        supportMapFragment = (SupportMapFragment)getChildFragmentManager().findFragmentById(R.id.map);
        supportMapFragment.getMapAsync(this);

        genderIcon = (ImageView)view.findViewById(R.id.gender_view);

        personName = (TextView)view.findViewById(R.id.personName);

        eventInfo = (TextView)view.findViewById(R.id.eventInfo);

        information = (RelativeLayout)view.findViewById(R.id.information);

        if(curEvent != null) {
            updateInformation(curEvent);
        }

        information.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), PersonActivity.class);
                intent.putExtra("personId", curPerson.getPersonId());
                startActivity(intent);
            }
        });


        return view;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        filtered = new HashSet<>();
        markers = new HashSet<>();
        lines = new HashSet<>();
        HashMap<String, Event> events = Model.getModel().getEvent();
        makeMarker(events);
        if(curPerson != null) {
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(curEvent.getLatitude(), curEvent.getLongitude()), 3.0f));
        }

        mMap.setOnMarkerClickListener(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        supportMapFragment.onResume();
        HashMap<String, Event> events = Model.getModel().getEvent();

        if(mMap != null) {
            mMap.setMapType(setmapType(Settings.getSettings().getMapType()));
            Event event = null;
            if(curMarker != null) {
                event = ((Event)curMarker.getTag());
                if(filtered.contains(event)) {
                    mMap.clear();
                    events.remove(event.getEventId());
                    makeMarker(events);
                }
                else {
                    mMap.clear();
                    makeMarker(events);
                    updateInformation(curEvent);
                    drawLine(curEvent);
                }
            }
            else {
                mMap.clear();
                makeMarker(events);
            }


        }
    }

    private void erase() {
    }

    @Override
    public boolean onMarkerClick(final Marker marker) {
        curMarker = marker;
        Event event = ((Event)marker.getTag());
        updateInformation(event);
        drawLine(event);
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(curEvent.getLatitude(), curEvent.getLongitude()), 3.0f));
        return true;
    }

    private Integer setmapType(int type) {
        if(type == 0) {
            return GoogleMap.MAP_TYPE_NORMAL;
        }
        else if(type == 1) {
            return GoogleMap.MAP_TYPE_HYBRID;
        }
        else if(type == 2) {
            return GoogleMap.MAP_TYPE_SATELLITE;
        }
        else if(type == 3) {
            return GoogleMap.MAP_TYPE_TERRAIN;
        }
        else
            return GoogleMap.MAP_TYPE_NORMAL;
    }

    private void makeMarker(HashMap<String, Event> events) {
        float color = 0;
        boolean filtering = false;
        for(String key : events.keySet()) {
            Event event  = events.get(key);

            //check event type filter
            if(event.getEventType().toLowerCase().contains("birth")) {
                if(Fillter.getFillter().isBirth()) {
                    color = BitmapDescriptorFactory.HUE_ORANGE;
                    filtering = true;
                }
                else {
                    filtering = false;
                    filtered.add(event);
                }
            }
            else if(event.getEventType().toLowerCase().contains("baptism")) {
                if(Fillter.getFillter().isBaptism()) {
                    color = BitmapDescriptorFactory.HUE_BLUE;
                    filtering = true;
                }
                else {
                    filtering = false;
                    filtered.add(event);
                }
            }
            else if(event.getEventType().toLowerCase().contains("marriage")) {
                if(Fillter.getFillter().isMarriage()) {
                    color = BitmapDescriptorFactory.HUE_YELLOW;
                    filtering = true;
                }
                else {
                    filtering = false;
                    filtered.add(event);
                }
            }

            else if(event.getEventType().toLowerCase().contains("death")) {
                if(Fillter.getFillter().isDeath()) {
                    color = BitmapDescriptorFactory.HUE_VIOLET;
                    filtering = true;
                }
                else {
                    filtering = false;
                    filtered.add(event);
                }
            }
            else if(!event.getEventType().toLowerCase().contains("birth") && !event.getEventType().toLowerCase().contains("baptism") &&
                    !event.getEventType().toLowerCase().contains("marriage") && !event.getEventType().toLowerCase().contains("death")) {
                Random random = new Random();
                color = (float) random.nextInt(360);
                filtering = true;
            }
            //check male, female filter
            if(Model.getModel().getPersonByPersonId(event.getPersonId()).
                    getGender().equals("m") && !(Fillter.getFillter().isMale())) {
                filtering = false;
                filtered.add(event);
            }
            else if(Model.getModel().getPersonByPersonId(event.getPersonId()).
                    getGender().equals("f") && !(Fillter.getFillter().isFemale())) {
                filtering = false;
                filtered.add(event);
            }
            //check father side, mother side filter
            if(Model.getModel().getPaternalAncestors().contains(event.getPersonId()) &&
                    !(Fillter.getFillter().isFatherSide())) {
                filtering = false;
                filtered.add(event);
            }
            else if(Model.getModel().getMaternalAncestors().contains(event.getPersonId()) &&
                    !(Fillter.getFillter().isMotherSide())) {
                filtering = false;
                filtered.add(event);
            }

            if(filtering) {
                LatLng latLng = new LatLng(event.getLatitude(), event.getLongitude());
                Marker marker = mMap.addMarker(new MarkerOptions().position(latLng)
                        .icon(BitmapDescriptorFactory.defaultMarker(color))
                        .visible(filtering)
                        .title(event.getCity() + ", " + event.getCountry() + "(" + event.getYear() + ")"));
                marker.setTag(event);
            }
        }
    }

    private void drawLine(Event event) {
        if(curPerson != null) {
            if(Settings.getSettings().isSpouseLineCheck()) {
                drawSpouseLines(event);
            }
            if(Settings.getSettings().isTreeLineCheck()) {
                drawFamilyTreeLines(event);
            }
            if(Settings.getSettings().isStoryLineCheck()) {
                drawLifeStoryLines();
            }
        }
    }

    private void drawSpouseLines(Event event) {
        int color = Settings.getSettings().getSpouseLineColor();
        LatLng curLocation = new LatLng(event.getLatitude(), event.getLongitude());
        String spouseId = curPerson.getSpouse();
        if(spouseId != null) { //check if there is spouse
            if (Model.getModel().getPersonEvents().get(spouseId) != null) {
                List<Event> orderedList = Model.getModel().getSortedEvents(Model.getModel().getPersonEvents().get(spouseId));
                if(orderedList.size() >0) {
                    Event spouseEvent = orderedList.get(0);
                    LatLng spouseLocation = new LatLng(spouseEvent.getLatitude(), spouseEvent.getLongitude());
                    PolylineOptions options = new PolylineOptions().add(curLocation, spouseLocation).width(5).color(color);
                    if (filtered.contains(spouseEvent) || filtered.contains(event)) {
                        options = new PolylineOptions().add(curLocation, spouseLocation).width(5).color(color).visible(false);
                    }
                    Polyline line = mMap.addPolyline(options);
                    if(line.isVisible()) {
                        line.setTag(event);
                        lines.add(line);
                    }
                }
            }
        }
    }

    private void drawFamilyTreeLines(Event event){
        Person person = curPerson;
        float thickness = 6.0f;
        familyTreeRecurse(person, event, thickness);
    }

    private void drawLifeStoryLines() {
        int color = Settings.getSettings().getStoryLineColor();

        List<Event> personEvents = Model.getModel().getPersonEvents().get(curPerson.getPersonId());
        List<Event> orderedList = Model.getModel().getSortedEvents(personEvents);
        if(orderedList.size() > 0) {
            for (int i = 0; i < orderedList.size() - 1; i++) {
                Event e1 = orderedList.get(i);
                Event e2 = orderedList.get(i + 1);
                LatLng curLocation = new LatLng(e1.getLatitude(), e1.getLongitude());
                LatLng nextLocation = new LatLng(e2.getLatitude(), e2.getLongitude());
                PolylineOptions options = new PolylineOptions().add(curLocation, nextLocation).width(5).color(color);
                if (filtered.contains(e1) || filtered.contains(e2)) {
                    options = new PolylineOptions().add(curLocation, nextLocation).width(5).color(color).visible(false);
                }
                Polyline line = mMap.addPolyline(options);
                if(line.isVisible()) {
                    line.setTag(e1);
                    lines.add(line);
                }
            }
        }
    }

    private void updateInformation(Event event) {
        curEvent = event;
        curPerson = Model.getModel().getPersonByPersonId(event.getPersonId());
        personName.setText(curPerson.toString());
        eventInfo.setText(curEvent.toString());
        if(curPerson.getGender().equals("f")) {
            genderIcon.setImageDrawable(new IconDrawable(getActivity(), FontAwesomeIcons.fa_female).colorRes(R.color.female_icon).sizeDp(40));
        }
        else if(curPerson.getGender().equals("m")) {
            genderIcon.setImageDrawable(new IconDrawable(getActivity(), FontAwesomeIcons.fa_male).colorRes(R.color.male_icon).sizeDp(40));
        }
    }

    private void familyTreeRecurse(Person person, Event event, float thickness) {
        int color = Settings.getSettings().getTreeLineColor();
        if(person.getFather() != null) {
            Person father = Model.getModel().getPersonByPersonId(person.getFather());
            if(Model.getModel().getPersonEvents().get(father.getPersonId()).size() > 0) {
                List<Event> orderedList = Model.getModel().getSortedEvents(Model.getModel().getPersonEvents().get(father.getPersonId()));
                if(orderedList.size() > 0) {
                    Event fatherEvent = orderedList.get(0);

                    LatLng curLocation = new LatLng(event.getLatitude(), event.getLongitude());
                    LatLng nextLocation = new LatLng(fatherEvent.getLatitude(), fatherEvent.getLongitude());
                    PolylineOptions options = new PolylineOptions().add(curLocation, nextLocation).width(thickness).color(color);

                    if (filtered.contains(fatherEvent) || filtered.contains(event)) {
                        options = new PolylineOptions().add(curLocation, nextLocation).width(thickness).color(color).visible(false);
                    }

                    Polyline line = mMap.addPolyline(options);
                    if(line.isVisible()) {
                        line.setTag(event);
                        lines.add(line);
                    }
                    familyTreeRecurse(father, fatherEvent, thickness - 1.5f);
                }
            }
        }
        if(person.getMother() != null) {
            Person mother = Model.getModel().getPersonByPersonId(person.getMother());
            if(Model.getModel().getPersonEvents().get(mother.getPersonId()).size() > 0) {
                List<Event> orderedList = Model.getModel().getSortedEvents(Model.getModel().getPersonEvents().get(mother.getPersonId()));
                if(orderedList.size() > 0) {
                    Event motherEvent = orderedList.get(0);

                    LatLng curLocation = new LatLng(event.getLatitude(), event.getLongitude());
                    LatLng nextLocation = new LatLng(motherEvent.getLatitude(), motherEvent.getLongitude());
                    PolylineOptions options = new PolylineOptions().add(curLocation, nextLocation).width(thickness).color(color);

                    if (filtered.contains(motherEvent)) {
                        options = new PolylineOptions().add(curLocation, nextLocation).width(thickness).color(color).visible(false);
                    }

                    Polyline line = mMap.addPolyline(options);
                    if(line.isVisible()) {
                        line.setTag(event);
                        lines.add(line);
                    }

                    familyTreeRecurse(mother, motherEvent, thickness - 1.5f);
                }
            }
        }
    }
}
