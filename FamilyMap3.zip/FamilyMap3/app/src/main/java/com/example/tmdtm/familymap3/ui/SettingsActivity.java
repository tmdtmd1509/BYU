package com.example.tmdtm.familymap3.ui;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.TestLooperManager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.example.tmdtm.familymap3.MainActivity;
import com.example.tmdtm.familymap3.R;
import com.example.tmdtm.familymap3.model.Model;
import com.example.tmdtm.familymap3.model.Settings;

import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends AppCompatActivity {

    private TextView lifeStory;
    private TextView lifeStoryDescription;
    private TextView familyTree;
    private TextView familyTreeDescription;
    private TextView spouse;
    private TextView spouseDescription;
    private TextView mapType;
    private TextView mapTypeDescription;
    private TextView resyncData;
    private TextView resyncDataDescription;
    private TextView logOut;
    private TextView logOutDescription;

    private Spinner storyLineSpinner;
    private Switch storyLineSwitch;
    private Spinner treeLineSpinner;
    private Switch treeLineSwitch;
    private Spinner spouseLineSpinner;
    private Switch spouseLineSwitch;
    private Spinner mapTypeSpinner;
    private LinearLayout reSync;
    private LinearLayout logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("FamilyMap: Settings");
    }

    @Override
    protected void onResume() {
        super.onResume();

        //Text view
        lifeStory = (TextView) findViewById(R.id.life_story_lines);
        lifeStoryDescription = (TextView) findViewById(R.id.life_story_line_description);
        familyTree = (TextView) findViewById(R.id.family_tree_lines);
        familyTreeDescription = (TextView) findViewById(R.id.family_tree_line_description);
        spouse = (TextView) findViewById(R.id.spouse_lines);
        spouseDescription = (TextView) findViewById(R.id.spouse_line_description);
        mapType = (TextView) findViewById(R.id.map_type);
        mapTypeDescription = (TextView)  findViewById(R.id.map_type_description);
        resyncData  = (TextView) findViewById(R.id.re_sync);
        resyncDataDescription = (TextView) findViewById(R.id.re_sync_description);
        logOut = (TextView) findViewById(R.id.logout);
        logOutDescription = (TextView) findViewById(R.id.logout_description);

        //make drop down menu
        List<String> colorList = new ArrayList<>();
        colorList.add("Green");
        colorList.add("Blue");
        colorList.add("Red");

//        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, colorList); //TA qeustion
        ArrayAdapter<CharSequence> adapter =ArrayAdapter.createFromResource(this, R.array.line_color_arrays, R.layout.support_simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);

        //life story settings
        storyLineSpinner = (Spinner) findViewById(R.id.life_story_spinner);
        storyLineSpinner.setAdapter(adapter);
        int storyColor = Settings.getSettings().transToSelectionNum(Settings.getSettings().getStoryLineColor());
        storyLineSpinner.setSelection(storyColor);
        storyLineSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                switch (position) {
                    case 0:
                        Settings.getSettings().setStoryLineColor(Color.GREEN);
                        break;
                    case 1:
                        Settings.getSettings().setStoryLineColor(Color.BLUE);
                        break;
                    case 2:
                        Settings.getSettings().setStoryLineColor(Color.RED);
                        break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) { }
        });

        storyLineSwitch = (Switch) findViewById(R.id.life_story_switch);
        storyLineSwitch.setChecked(Settings.getSettings().isStoryLineCheck());
        storyLineSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Settings.getSettings().setStoryLineCheck(b);
            }
        });

        //Family tree settings
        treeLineSpinner = (Spinner) findViewById(R.id.family_tree_spinner);
        treeLineSpinner.setAdapter(adapter);
        int treeColor = Settings.getSettings().transToSelectionNum(Settings.getSettings().getTreeLineColor());
        treeLineSpinner.setSelection(treeColor);
        treeLineSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                switch (position) {
                    case 0:
                        Settings.getSettings().setTreeLineColor(Color.GREEN);
                        break;
                    case 1:
                        Settings.getSettings().setTreeLineColor(Color.BLUE);
                        break;
                    case 2:
                        Settings.getSettings().setTreeLineColor(Color.RED);
                        break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) { }
        });

        treeLineSwitch = (Switch) findViewById(R.id.family_tree_switch);
        treeLineSwitch.setChecked(Settings.getSettings().isTreeLineCheck());
        treeLineSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Settings.getSettings().setTreeLineCheck(b);
            }
        });

        //Spouse settings
        spouseLineSpinner = (Spinner) findViewById(R.id.spouse_spinner);
        spouseLineSpinner.setAdapter(adapter);
        int spouseColor = Settings.getSettings().transToSelectionNum(Settings.getSettings().getSpouseLineColor());
        spouseLineSpinner.setSelection(spouseColor);
        spouseLineSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                switch (position) {
                    case 0:
                        Settings.getSettings().setSpouseLineColor(Color.GREEN);
                        break;
                    case 1:
                        Settings.getSettings().setSpouseLineColor(Color.BLUE);
                        break;
                    case 2:
                        Settings.getSettings().setSpouseLineColor(Color.RED);
                        break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) { }
        });

        spouseLineSwitch = (Switch) findViewById(R.id.spouse_switch);
        spouseLineSwitch.setChecked(Settings.getSettings().isSpouseLineCheck());
        spouseLineSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Settings.getSettings().setSpouseLineCheck(b);
            }
        });


        List<String> mapList = new ArrayList<>();
        mapList.add("Normal");
        mapList.add("Hybrid");
        mapList.add("Satellite");
        mapList.add("Terrain");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, mapList); //TA qeustion
        arrayAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);

        //Map Type settings
        mapTypeSpinner = (Spinner) findViewById(R.id.map_type_spinner);
        mapTypeSpinner.setAdapter(arrayAdapter);
        mapTypeSpinner.setSelection(Settings.getSettings().getMapType());
        mapTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                switch (position) {
                    case 0:
                        Settings.getSettings().setMapType(0);
                        break;
                    case 1:
                        Settings.getSettings().setMapType(1);
                        break;
                    case 2:
                        Settings.getSettings().setMapType(2);
                        break;
                    case 3:
                        Settings.getSettings().setMapType(3);
                        break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) { }
        });

        //re_sync setting
        reSync = (LinearLayout) findViewById(R.id.re_sync_setting);
        reSync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
/*
                String host = LoginFragment.getLoginFragment().host;
                String port  = LoginFragment.getLoginFragment().port;
                LoginFragment.PeopleTask peopleTask = new LoginFragment.PeopleTask();//TA question
                peopleTask.execute(Model.getModel().authToken, host, port);
*/

            }
        });
        //logout setting
        logout = (LinearLayout) findViewById(R.id.logout_setting);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Model.getModel().user = null;
                Intent intent = new Intent(view.getContext(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                Model.getModel().logout();
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.home://need to fix
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
