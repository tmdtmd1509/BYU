package com.example.tmdtm.familymap3.model;

import java.util.HashMap;
import java.util.Map;

public class Fillter {

    private boolean birth;
    private boolean baptism;
    private boolean death;
    private boolean marriage;
    private boolean fatherSide;
    private boolean motherSide;
    private boolean male;
    private boolean female;
    public HashMap<Integer, Boolean> checkOnOff;

    private static Fillter fillter;
    private Fillter() {
        birth = true;
        baptism = true;
        death = true;
        marriage = true;
        fatherSide = true;
        motherSide = true;
        male =true;
        female = true;
        checkOnOff = new HashMap<>();
    }

    public static Fillter getFillter() {
        if(fillter == null) {
            fillter = new Fillter();
        }
        return fillter;
    }

    public void reset() {
        birth = true;
        baptism = true;
        death = true;
        marriage = true;
        fatherSide = true;
        motherSide = true;
        male =true;
        female = true;
        checkOnOff = new HashMap<>();
    }

    public boolean isBirth() {
        return birth;
    }

    public void setBirth(boolean birth) {
        this.birth = birth;
    }

    public boolean isBaptism() {
        return baptism;
    }

    public void setBaptism(boolean baptism) {
        this.baptism = baptism;
    }

    public boolean isDeath() {
        return death;
    }

    public void setDeath(boolean death) {
        this.death = death;
    }

    public boolean isFatherSide() {
        return fatherSide;
    }

    public void setFatherSide(boolean fatherSide) {
        this.fatherSide = fatherSide;
    }

    public boolean isMarriage() {
        return marriage;
    }

    public void setMarriage(boolean marriage) {
        this.marriage = marriage;
    }

    public boolean isMotherSide() {
        return motherSide;
    }

    public void setMotherSide(boolean motherSide) {
        this.motherSide = motherSide;
    }

    public boolean isMale() {
        return male;
    }

    public void setMale(boolean male) {
        this.male = male;
    }

    public boolean isFemale() {
        return female;
    }

    public void setFemale(boolean female) {
        this.female = female;
    }


}
