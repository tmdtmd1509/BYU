package com.example.tmdtm.familymap3.net;

import com.example.tmdtm.familymap3.model.User;
import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class ServerProxy {
    public static String login(String serverHost, String serverPort, String userName, String password) {
        System.out.println("login called");
        try {

            URL url = new URL("http://" + serverHost + ":" + serverPort + "/user/login");
            HttpURLConnection http = (HttpURLConnection)url.openConnection();
            http.setRequestMethod("POST");
            http.setDoOutput(true);
            http.connect();
            String reqData =
                    "{" + "\"userName\": " + userName + ",\n" +
                            "\"password\": " + password + "}";

            OutputStream reqBody = http.getOutputStream();
            writeString(reqData, reqBody);
            reqBody.close();

            if (http.getResponseCode() == HttpURLConnection.HTTP_OK) {
                InputStream respBody = http.getInputStream();
                System.out.println("got response");
                return readString(respBody);
            }
            else {
                System.out.println("no response");
                return null;
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("connection failed");
        return null;
    }

    public static String register(String serverHost, String serverPort, User request) {
        try {
            URL url = new URL("http://" + serverHost + ":" + serverPort + "/user/register");
            HttpURLConnection http = (HttpURLConnection)url.openConnection();
            http.setRequestMethod("POST");
            http.setDoOutput(true);	// There is a request body
            http.connect();
            Gson gson = new Gson();

            String reqData = gson.toJson(request);

            OutputStream reqBody = http.getOutputStream();
            writeString(reqData, reqBody);
            reqBody.close();
            if (http.getResponseCode() == HttpURLConnection.HTTP_OK) {
                InputStream respBody = http.getInputStream();
                System.out.println("got response");
                return readString(respBody);
            }
            else {
                System.out.println("ERROR: " + http.getResponseMessage());
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String people(String serverHost, String serverPort, String authToken) {
        System.out.println("people called");

        try {
            URL url = new URL("http://" + serverHost + ":" + serverPort + "/person");
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            http.setRequestMethod("GET");
            http.setDoOutput(false);
            http.addRequestProperty("Authorization", authToken);
            http.connect();

            if (http.getResponseCode() == HttpURLConnection.HTTP_OK) {
                InputStream respBody = http.getInputStream();
                System.out.println("got response");
                return readString(respBody);
            } else {
                System.out.println("no response");
                return null;
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String event(String serverHost, String serverPort, String authToken) {
        System.out.println("event called");
        try {
            URL url = new URL("http://" + serverHost + ":" + serverPort + "/event");
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            http.setRequestMethod("GET");
            http.setDoOutput(false);
            http.addRequestProperty("Authorization", authToken);
            http.connect();


            if (http.getResponseCode() == HttpURLConnection.HTTP_OK) {
                InputStream respBody = http.getInputStream();
                System.out.println("got response");
                return readString(respBody);
            } else {
                System.out.println("no response");
                return null;
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String person(String serverHost, String serverPort, String authToken, String personId) {
        System.out.println("people called");

        try {
            URL url = new URL("http://" + serverHost + ":" + serverPort + "/person/" + personId);
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            http.setRequestMethod("GET");
            http.setDoOutput(false);
            http.addRequestProperty("Authorization", authToken);
            http.connect();

            if (http.getResponseCode() == HttpURLConnection.HTTP_OK) {
                InputStream respBody = http.getInputStream();
                System.out.println("got response");
                return readString(respBody);
            } else {
                System.out.println("no response");
                return null;
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /*
        The readString method shows how to read a String from an InputStream.
    */
    private static String readString(InputStream is) throws IOException {
        StringBuilder sb = new StringBuilder();
        InputStreamReader sr = new InputStreamReader(is);
        char[] buf = new char[1024];
        int len;
        while ((len = sr.read(buf)) > 0) {
            sb.append(buf, 0, len);
        }
        return sb.toString();
    }

    /*
        The writeString method shows how to write a String to an OutputStream.
    */
    private static void writeString(String str, OutputStream os) throws IOException {
        OutputStreamWriter sw = new OutputStreamWriter(os);
        sw.write(str);
        sw.flush();
    }
}