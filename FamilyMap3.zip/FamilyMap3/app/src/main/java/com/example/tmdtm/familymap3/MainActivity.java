package com.example.tmdtm.familymap3;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.example.tmdtm.familymap3.model.Model;
import com.example.tmdtm.familymap3.ui.FilterActivity;
import com.example.tmdtm.familymap3.ui.LoginFragment;
import com.example.tmdtm.familymap3.ui.MapFragment;
import com.example.tmdtm.familymap3.ui.SearchActivity;
import com.example.tmdtm.familymap3.ui.SettingsActivity;
import com.joanzapata.iconify.IconDrawable;
import com.joanzapata.iconify.Iconify;
import com.joanzapata.iconify.fonts.FontAwesomeIcons;
import com.joanzapata.iconify.fonts.FontAwesomeModule;


public class MainActivity extends AppCompatActivity {
//    public String serverHost;
//    public String serverPort;
    private MenuItem searchMenu;
    private MenuItem filterMenu;
    private MenuItem settingsMenu;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Iconify.with(new FontAwesomeModule());

        FragmentManager fm = getSupportFragmentManager();
        Fragment fragment = fm.findFragmentById(R.id.fragment_container);
//
//        if(fragment == null) {
//            fragment = new LoginFragment();
//            fm.beginTransaction().add(R.id.fragment_container, fragment).commit();
//        }
        if(Model.getModel().hasUser()) {
            //map fragment
                fragment = new MapFragment();
                fm.beginTransaction().add(R.id.fragment_container, fragment).commit();
        }
        else {
            fragment = new LoginFragment();
            fm.beginTransaction().add(R.id.fragment_container, fragment).commit();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);

        searchMenu = menu.findItem(R.id.search);
        searchMenu.setIcon(new IconDrawable(this, FontAwesomeIcons.fa_search).colorRes(R.color.menu).sizeDp(40));

        filterMenu = menu.findItem(R.id.filter);
        filterMenu.setIcon(new IconDrawable(this, FontAwesomeIcons.fa_filter).colorRes(R.color.menu).sizeDp(40));

        settingsMenu = menu.findItem(R.id.settings);
        settingsMenu.setIcon(new IconDrawable(this, FontAwesomeIcons.fa_gear).colorRes(R.color.menu).sizeDp(40));

        if(!Model.getModel().hasUser()) {
            searchMenu.setVisible(false);
            filterMenu.setVisible(false);
            settingsMenu.setVisible(false);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int button  = item.getItemId();
        if(button == R.id.search) {
            Intent intent = new Intent(MainActivity.this, SearchActivity.class);
            startActivity(intent);
            return true;
        }
        else if(button == R.id.filter) {
            Intent intent = new Intent(MainActivity.this, FilterActivity.class);
            startActivity(intent);
            return true;
        }
        else if(button == R.id.settings) {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item) ;
    }
}
