package com.example.tmdtm.familymap3.net;

import com.example.tmdtm.familymap3.model.Person;

import java.util.List;

/**
 * response of person's whole people
 */
public class PeopleResponse {
    public String message;
    public List<Person> data;
}
