package com.example.tmdtm.familymap3.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import com.example.tmdtm.familymap3.R;
import com.example.tmdtm.familymap3.model.Event;
import com.example.tmdtm.familymap3.model.Model;
import com.example.tmdtm.familymap3.model.Person;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {

    private List<Object> list;
    private EditText search_bar;
    private ListView listView;
    private SearchAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("FamilyMap: Search");

        search_bar = (EditText) findViewById(R.id.search_bar);
        search_bar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override
            public void afterTextChanged(Editable editable) {
                search(search_bar.getText().toString());
            }
        });

        listView = (ListView) findViewById(R.id.listView);
        //make list
        list = new ArrayList<Object>();
        adapter = new SearchAdapter(list, this);

        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Object item = list.get(position);
                if (item instanceof Event) {
                    Intent intent = new Intent(SearchActivity.this, EventActivity.class);
                    intent.putExtra("eventId", ((Event)item).getEventId());//works only when eventlist is sorted
                    startActivity(intent);
                }
                else {
                    Intent intent = new Intent(getApplicationContext(), PersonActivity.class);
                    intent.putExtra("personId", ((Person)item).getPersonId());
                    startActivity(intent);
                }
            }
        });
    }

    public void search(String charText) {
        String word = charText.toLowerCase();
        //reset list every time text typed
        list.clear();
        for (Person person : Model.getModel().personList) {
            if(person.getFirstName().toLowerCase().contains(word) || person.getLastName().toLowerCase().contains(word)) {
                list.add(person);
            }
        }
        for (Event event : Model.getModel().eventList) {
            if(event.toString().toLowerCase().contains(word) || event.toString().toLowerCase().contains(word)) {
                list.add(event);
            }
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu_top, menu);
//
//        menu.findItem(R.id.menu_top).setIcon(new IconDrawable(this, FontAwesomeIcons.fa_angle_double_up)
//        .colorRes(R.color.menu));

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.home://need to fix
                finish();
                return true;
//            case R.id.menu_top:
//                Intent intent = new Intent(this, MainActivity.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                startActivity(intent);
//                finish();
//                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
