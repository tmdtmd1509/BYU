package com.example.tmdtm.familymap3.net;

/**
 * response of Load
 */
public class LoadResponse {
    public String message;
    public int userNum;
    public int personNum;
    public int eventNum;
}
