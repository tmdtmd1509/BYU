package com.example.tmdtm.familymap3.model;

import android.content.Context;
import android.graphics.Color;

public class Settings {

    private int storyLineColor;
    private boolean storyLineCheck;
    private int treeLineColor;
    private boolean treeLineCheck;
    private int spouseLineColor;
    private boolean spouseLineCheck;
    private int mapType;


    private static Settings settings = new Settings();
    private Settings() {
        storyLineColor = Color.GREEN;
        storyLineCheck = true;
        treeLineColor = Color.BLUE;
        treeLineCheck = true;
        spouseLineColor = Color.RED;
        spouseLineCheck = true;
        mapType = 0;
    }

    public static Settings getSettings() {
        if(settings == null) {
            settings = new Settings();
        }
        return settings;
    }

    public void reset() {
        storyLineColor = Color.GREEN;
        storyLineCheck = true;
        treeLineColor = Color.BLUE;
        treeLineCheck = true;
        spouseLineColor = Color.RED;
        spouseLineCheck = true;
        mapType = 0;
    }


    public int getStoryLineColor() {
        return storyLineColor;
    }

    public void setStoryLineColor(int storyLineColor) {
        this.storyLineColor = storyLineColor;
    }

    public boolean isStoryLineCheck() {
        return storyLineCheck;
    }

    public void setStoryLineCheck(boolean storyLineCheck) {
        this.storyLineCheck = storyLineCheck;
    }

    public int getTreeLineColor() {
        return treeLineColor;
    }

    public void setTreeLineColor(int treeLineColor) {
        this.treeLineColor = treeLineColor;
    }

    public boolean isTreeLineCheck() {
        return treeLineCheck;
    }

    public void setTreeLineCheck(boolean treeLineCheck) {
        this.treeLineCheck = treeLineCheck;
    }

    public int getSpouseLineColor() {
        return spouseLineColor;
    }

    public void setSpouseLineColor(int spouseLineColor) {
        this.spouseLineColor = spouseLineColor;
    }

    public boolean isSpouseLineCheck() {
        return spouseLineCheck;
    }

    public void setSpouseLineCheck(boolean spouseLineCheck) {
        this.spouseLineCheck = spouseLineCheck;
    }

    public int getMapType() {
        return mapType;
    }

    public void setMapType(int mapType) {
        this.mapType = mapType;
    }

    public int transToSelectionNum(int color) {
        if(color == Color.GREEN) {
            return 0;
        }
        else if(color == Color.BLUE) {
            return 1;
        }
        else if(color == Color.RED) {
            return 2;
        }
        else return 0;
    }
}
