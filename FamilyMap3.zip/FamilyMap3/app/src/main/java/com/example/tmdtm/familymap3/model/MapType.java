package com.example.tmdtm.familymap3.model;

public class MapType {
}
