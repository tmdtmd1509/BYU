package com.example.tmdtm.familymap3.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.example.tmdtm.familymap3.R;
import com.example.tmdtm.familymap3.model.Fillter;

public class FilterActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);

        getSupportActionBar().setTitle("FamilyMap: Filter");
    }

    @Override
    protected void onResume() {
        super.onResume();

        //text view main
        TextView baptism_events = (TextView) findViewById(R.id.baptism_events);
        TextView birth_events = (TextView) findViewById(R.id.birth_events);
        TextView death_events = (TextView) findViewById(R.id.death_events);
        TextView marriage_events = (TextView) findViewById(R.id.marriage_events);
        TextView father_side = (TextView) findViewById(R.id.father_side);
        TextView mother_side = (TextView) findViewById(R.id.mother_side);
        TextView male_events = (TextView) findViewById(R.id.male_events);
        TextView female_events = (TextView) findViewById(R.id.female_events);

        //text view description
        TextView baptism_events_description = (TextView) findViewById(R.id.baptism_events_description);
        TextView birth_events_description = (TextView) findViewById(R.id.birth_events_description);
        TextView death_events_description = (TextView) findViewById(R.id.death_events_description);
        TextView marriage_events_description = (TextView) findViewById(R.id.marriage_events_description);
        TextView father_side_description = (TextView) findViewById(R.id.father_side_description);
        TextView mother_side_description = (TextView) findViewById(R.id.mother_side_description);
        TextView male_events_description = (TextView) findViewById(R.id.male_events_description);
        TextView female_events_description = (TextView) findViewById(R.id.female_events_description);

        //switch
        Switch baptism_switch = (Switch) findViewById(R.id.baptism_switch);
        baptism_switch.setChecked(Fillter.getFillter().isBaptism());
        baptism_switch.setOnCheckedChangeListener(this);

        Switch birth_switch = (Switch) findViewById(R.id.birth_switch);
        birth_switch.setChecked(Fillter.getFillter().isBirth());
        birth_switch.setOnCheckedChangeListener(this);

        Switch death_switch = (Switch) findViewById(R.id.death_switch);
        death_switch.setChecked(Fillter.getFillter().isDeath());
        death_switch.setOnCheckedChangeListener(this);

        Switch marriage_switch = (Switch) findViewById(R.id.marriage_switch);
        marriage_switch.setChecked(Fillter.getFillter().isMarriage());
        marriage_switch.setOnCheckedChangeListener(this);

        Switch fatherSide_switch = (Switch) findViewById(R.id.fatherSide_switch);
        fatherSide_switch.setChecked(Fillter.getFillter().isFatherSide());
        fatherSide_switch.setOnCheckedChangeListener(this);

        Switch motherSide_switch = (Switch) findViewById(R.id.motherSide_switch);
        motherSide_switch.setChecked(Fillter.getFillter().isMotherSide());
        motherSide_switch.setOnCheckedChangeListener(this);

        Switch male_switch = (Switch) findViewById(R.id.male_switch);
        male_switch.setChecked(Fillter.getFillter().isMale());
        male_switch.setOnCheckedChangeListener(this);

        Switch female_switch = (Switch) findViewById(R.id.female_switch);
        female_switch.setChecked(Fillter.getFillter().isFemale());
        female_switch.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        int button = compoundButton.getId();
        if(button == R.id.baptism_switch) {
            Fillter.getFillter().setBaptism(!(Fillter.getFillter().isBaptism()));
        }
        if(button == R.id.birth_switch) {
            Fillter.getFillter().setBirth(!(Fillter.getFillter().isBirth()));
        }
        if(button == R.id.death_switch) {
            Fillter.getFillter().setDeath(!(Fillter.getFillter().isDeath()));
        }
        if(button == R.id.marriage_switch) {
            Fillter.getFillter().setMarriage(!(Fillter.getFillter().isMarriage()));
        }
        if(button == R.id.fatherSide_switch) {
            Fillter.getFillter().setFatherSide(!(Fillter.getFillter().isFatherSide()));
        }
        if(button == R.id.motherSide_switch) {
            Fillter.getFillter().setMotherSide(!(Fillter.getFillter().isMotherSide()));
        }
        if(button == R.id.male_switch) {
            Fillter.getFillter().setMale(!(Fillter.getFillter().isMale()));
        }
        if(button == R.id.female_switch) {
            Fillter.getFillter().setFemale(!(Fillter.getFillter().isFemale()));
        }
    }
}
