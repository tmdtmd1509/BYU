package com.example.tmdtm.familymap3.net;

/**
 * response of request
 */
public class PersonResponse {
    public String personId;
    public String descendant;
    public String firstName;
    public String lastName;
    public String gender;
    public String father;
    public String mother;
    public String spouse;
    public String message;
}
