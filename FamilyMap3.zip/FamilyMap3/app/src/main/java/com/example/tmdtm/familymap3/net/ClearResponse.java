package com.example.tmdtm.familymap3.net;

/**
 * response of clear
 * it is just a message
 */
public class ClearResponse {
    public String message;
}
