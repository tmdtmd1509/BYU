package com.example.tmdtm.familymap3.model;

import com.example.tmdtm.familymap3.net.AllEventsResponse;
import com.example.tmdtm.familymap3.net.LoginResponse;
import com.example.tmdtm.familymap3.net.PeopleResponse;
import com.example.tmdtm.familymap3.net.PersonResponse;
import com.example.tmdtm.familymap3.net.ServerProxy;
import com.example.tmdtm.familymap3.ui.LoginFragment;
import com.google.gson.Gson;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class ModelTest {
    private User userRequest;
    private LoginResponse loginResponse;

    @Before
    public void setUp() {
        Model.getModel();
        userRequest = new User();
        loginResponse = new LoginResponse();

        String host = "192.168.1.224";
        String port = "8089";
        String userName = "username";
        String password = "password";
        String firstName = "Ethan";
        String lastName = "Hwang";
        String email = "email@eamil.com";
        String gender = "m";

        userRequest.setUsername(userName);
        userRequest.setPassword(password);
        userRequest.setFirstName(firstName);
        userRequest.setLastName(lastName);
        userRequest.setEmail(email);
        userRequest.setGender(gender);


        ServerProxy.register(host, port, userRequest);

        String json = ServerProxy.login(host, port, userName, password);

        Gson gson = new Gson();
        loginResponse = gson.fromJson(json, LoginResponse.class);

        Model.getModel().logIn();

        Model.getModel().user.setPersonId("personId0");
        Model.getModel().user.setDescendant("username");
        Model.getModel().user.setFather("personId");
        Model.getModel().user.setMother("personId2");
        Model.getModel().user.setFirstName("Ethan0");
        Model.getModel().user.setLastName("Hwang0");
        Model.getModel().user.setGender("m");
        Model.getModel().user.setSpouse(null);


        Person person1 =  new Person();
        person1.setPersonId("personId");
        person1.setFirstName("Ethan");
        person1.setLastName("Hwang");
        person1.setDescendant("username");
        person1.setGender("m");
        person1.setFather(null);
        person1.setMother(null);
        person1.setSpouse("personId2");

        Person person2 =  new Person();
        person2.setPersonId("personId2");
        person2.setFirstName("Ethan2");
        person2.setLastName("Hwang2");
        person2.setDescendant("username");
        person2.setGender("f");
        person2.setFather(null);
        person2.setMother(null);
        person2.setSpouse("personId");

        Model.getModel().personList = new ArrayList<>();
        Model.getModel().personList.add(person1);
        Model.getModel().personList.add(person2);
        Model.getModel().personList.add(Model.getModel().user);

        Event event1 = new Event();
        event1.setEventId("eventId");
        event1.setPersonId("personId");
        event1.setDescendant("username");
        event1.setCity("provo");
        event1.setCountry("UT");
        event1.setEventType("birth");
        event1.setLatitude(1.0);
        event1.setLongitude(1.0);
        event1.setYear(1992);

        Event event2 = new Event();
        event2.setEventId("eventId2");
        event2.setPersonId("personId");
        event2.setDescendant("username");
        event2.setCity("provo");
        event2.setCountry("UT");
        event2.setEventType("marriage");
        event2.setLatitude(1.0);
        event2.setLongitude(1.0);
        event2.setYear(2010);

        Event event3 = new Event();
        event3.setEventId("eventId3");
        event3.setPersonId("personId2");
        event3.setDescendant("username");
        event3.setCity("provo");
        event3.setCountry("UT");
        event3.setEventType("birth");
        event3.setLatitude(1.0);
        event3.setLongitude(1.0);
        event3.setYear(1993);

        Event event4 = new Event();
        event4.setEventId("eventId4");
        event4.setPersonId("personId2");
        event4.setDescendant("username");
        event4.setCity("provo");
        event4.setCountry("UT");
        event4.setEventType("marriage");
        event4.setLatitude(1.0);
        event4.setLongitude(1.0);
        event4.setYear(2010);


        Model.getModel().eventList = new ArrayList<>();
        Model.getModel().eventList.add(event1);
        Model.getModel().eventList.add(event2);
        Model.getModel().eventList.add(event3);
        Model.getModel().eventList.add(event4);
    }

    @After
    public void tearDown() {

    }

    @Test
    public void makeMaps() {
        assertEquals(Model.getModel().getEvent().size(), 0);
        assertEquals(Model.getModel().getPeople().size(), 0);
        assertEquals(Model.getModel().getPersonChildren().size(), 0);

        Model.getModel().makeMaps();
    }

    @Test
    public void getEvent() {
        assertNotNull(Model.getModel().getEvent());

    }
    @Test
    public void getPeople() {
        assertNotNull(Model.getModel().getPeople());
    }

    @Test
    public void getPaternalAncestors() {
        assertNotNull(Model.getModel().getPaternalAncestors());
    }

    @Test
    public void getMaternalAncestors() {
        assertNotNull(Model.getModel().getMaternalAncestors());
    }
}