package com.example.tmdtm.familymap3.net;

import com.example.tmdtm.familymap3.model.User;
import com.google.gson.Gson;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


import static org.junit.Assert.*;

public class ServerProxyTest {
    private User userRequest;
    private LoginResponse loginResponse;
    private LoginResponse loginResponse1;
    private PeopleResponse peopleResponse;
    private AllEventsResponse allEventsResponse;
    private PersonResponse personResponse;



    @Before
    public void setUp() {
        userRequest = new User();
        loginResponse = new LoginResponse();
        loginResponse1 = new LoginResponse();
        peopleResponse = new PeopleResponse();
        allEventsResponse = new AllEventsResponse();
        personResponse = new PersonResponse();
    }


    @After
    public void tearDown() {

    }

    @Test
    public void login() {
        //success case
        String host = "192.168.1.224";
        String port = "8089";
        String userName = "username";
        String password = "password";
        String firstName = "Ethan";
        String lastName = "Hwang";
        String email = "email@eamil.com";
        String gender = "m";

        userRequest.setUsername(userName);
        userRequest.setPassword(password);
        userRequest.setFirstName(firstName);
        userRequest.setLastName(lastName);
        userRequest.setEmail(email);
        userRequest.setGender(gender);


        ServerProxy.register(host, port, userRequest);

        String json = ServerProxy.login(host, port, userName, password);

        Gson gson = new Gson();
        loginResponse = gson.fromJson(json, LoginResponse.class);
        assertEquals(loginResponse.userName, userName);
        assertNotNull(loginResponse.authToken);

        //fail case
        String host1 = "192.168.1.224";
        String port1 = "8089";
        String userName1 = "differentName";
        String password1 = "password";

        String json1 = ServerProxy.login(host1, port1, userName1, password1);
        loginResponse1 = gson.fromJson(json1, LoginResponse.class);
        assertNotEquals(loginResponse1.userName, userName);
        assertNotEquals(loginResponse1.userName, userName1);
        assertNull(loginResponse1.authToken);
    }

    @Test
    public void register() {
        //success case
        String host = "192.168.1.224";
        String port = "8089";
        String userName = "username";
        String password = "password";
        String firstName = "Ethan";
        String lastName = "Hwang";
        String email = "email@eamil.com";
        String gender = "m";

        userRequest.setUsername(userName);
        userRequest.setPassword(password);
        userRequest.setFirstName(firstName);
        userRequest.setLastName(lastName);
        userRequest.setEmail(email);
        userRequest.setGender(gender);

        ServerProxy.register(host, port, userRequest);

        String json = ServerProxy.login(host, port, userName, password);

        Gson gson = new Gson();
        loginResponse = gson.fromJson(json, LoginResponse.class);
        assertEquals(loginResponse.userName, userName);
        assertNotNull(loginResponse.authToken);

        //fail case
        String host1 = "192.168.1.224";
        String port1 = "8089";
        String userName1 = "username1";
        String password1 = "password";
        String firstName1 = "Ethan";
        String lastName1 = "Hwang";
        String email1 = "email@eamil.com";
        String gender1 = "m/f";//wrong gender

        userRequest.setUsername(userName1);
        userRequest.setPassword(password1);
        userRequest.setFirstName(firstName1);
        userRequest.setLastName(lastName1);
        userRequest.setEmail(email1);
        userRequest.setGender(gender1);

        ServerProxy.register(host, port, userRequest);

        String json1 = ServerProxy.login(host1, port1, userName1, password1);

        Gson gson1 = new Gson();
        loginResponse1 = gson1.fromJson(json1, LoginResponse.class);
        assertNotEquals(loginResponse1.userName, userName1);
        assertNull(loginResponse1.authToken);
    }

    @Test
    public void people() {
        //success case
        String host = "192.168.1.224";
        String port = "8089";
        String userName = "username";
        String password = "password";

        String json = ServerProxy.login(host, port, userName, password);
        Gson gson = new Gson();
        loginResponse = gson.fromJson(json, LoginResponse.class);

        String authToken = loginResponse.authToken;

        String json1 = ServerProxy.people(host, port, authToken);
        Gson gson1 = new Gson();
        peopleResponse = gson1.fromJson(json1, PeopleResponse.class);

        assertNotNull(peopleResponse.data);
        assertEquals(peopleResponse.data.size(), 31);

        //fail case
        String host1 = "192.168.1.224";
        String port1 = "8089";
        String userName1 = "username";
        String password1 = "password";

        String json2 = ServerProxy.login(host1, port1, userName1, password1);
        Gson gson2 = new Gson();
        loginResponse1 = gson2.fromJson(json2, LoginResponse.class);

        String authToken1 = "wrong_authToken";//wrong authToken

        assertNotEquals(authToken, authToken1);

        String json3 = ServerProxy.people(host1, port1, authToken1);
        assertNull(json3);
    }

    @Test
    public void event() {
        //success case
        String host = "192.168.1.224";
        String port = "8089";
        String userName = "username";
        String password = "password";

        String json = ServerProxy.login(host, port, userName, password);
        Gson gson = new Gson();
        loginResponse = gson.fromJson(json, LoginResponse.class);

        String authToken = loginResponse.authToken;

        String json1 = ServerProxy.event(host, port, authToken);
        Gson gson1 = new Gson();
        allEventsResponse = gson1.fromJson(json1, AllEventsResponse.class);

        assertNotNull(allEventsResponse.data);
        assertEquals(allEventsResponse.data.size(), 122);

        //fail case
        String host1 = "192.168.1.224";
        String port1 = "8089";
        String userName1 = "username";
        String password1 = "password";

        String json2 = ServerProxy.login(host1, port1, userName1, password1);
        Gson gson2 = new Gson();
        loginResponse1 = gson2.fromJson(json2, LoginResponse.class);

        String authToken1 = "wrong_authToken";//wrong authToken

        assertNotEquals(authToken, authToken1);

        String json3 = ServerProxy.event(host1, port1, authToken1);
        assertNull(json3);
    }

    @Test
    public void person() {
        //success case
        String host = "192.168.1.224";
        String port = "8089";
        String userName = "username";
        String password = "password";


        String personId = "e3d8e57f-1b0d-4b1b-ad39-4ee58e4c6e3c";


        String json = ServerProxy.login(host, port, userName, password);
        Gson gson = new Gson();
        loginResponse = gson.fromJson(json, LoginResponse.class);

        String authToken = loginResponse.authToken;

        String json1 = ServerProxy.person(host, port, authToken, personId);
        Gson gson1 = new Gson();
        personResponse = gson1.fromJson(json1, PersonResponse.class);

        assertEquals(personResponse.firstName, "Ethan");
        assertEquals(personResponse.lastName, "Hwang");
        assertEquals(personResponse.gender, "m");

        //fail case
        String host1 = "192.168.1.224";
        String port1 = "8089";
        String userName1 = "username";
        String password1 = "password";

        String json2 = ServerProxy.login(host1, port1, userName1, password1);
        Gson gson2 = new Gson();
        loginResponse1 = gson2.fromJson(json2, LoginResponse.class);

        String authToken1 = "wrong_authToken";//wrong authToken

        assertNotEquals(authToken, authToken1);

        String json3 = ServerProxy.person(host1, port1, authToken1, personId);
        assertNull(json3);

        //fail case
        String host2 = "192.168.1.224";
        String port2 = "8089";
        String userName2 = "username";
        String password2 = "password";

        String json4 = ServerProxy.login(host2, port2, userName2, password2);
        Gson gson4 = new Gson();
        loginResponse1 = gson4.fromJson(json4, LoginResponse.class);

        String authToken2 = loginResponse1.authToken;

        assertNotEquals(authToken, authToken1);

        String personId1 = "wrong personId";//wrong person Id

        String json5 = ServerProxy.person(host2, port2, authToken2, personId1);
        Gson gson5 = new Gson();
        personResponse = gson5.fromJson(json5, PersonResponse.class);
        assertEquals(personResponse.message, "Invalid PersonId");

    }
}